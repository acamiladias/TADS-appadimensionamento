package tads.appdimensionamento

data class Modelo(
    val modelo: String,
    val pontuacaoMin: Int,
    val pontuacaoMax: Int,
    val btus: Int,
    val descricao: String
)
